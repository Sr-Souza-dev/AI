sigaa(gabriel, 123456).
sigaa(yuri, 123456).
sigaa(rodrigo, 123456).

materia(compiladores, gabriel, notas, 78).
materia(compiladores, gabriel, faltas, 2).
materia(compiladores, gabriel, tarefas, 3).
materia(ia, gabriel, notas, 99).
materia(ia, gabriel, faltas, 0).
materia(ia, gabriel, tarefas, 99).
materia(jogos, gabriel, notas, 99).
materia(jogos, gabriel, faltas, 4).
materia(jogos, gabriel, tarefas, 1).
materia(aeds, gabriel, notas, 82).
materia(aeds, gabriel, faltas, 2).
materia(aeds, gabriel, tarefas, 3).
materia(lfa, gabriel, notas, 82).
materia(lfa, gabriel, faltas, 1).
materia(lfa, gabriel, tarefas, 1).
materia(compiladores, yuri, notas, 79).
materia(compiladores, yuri, faltas, 4).
materia(compiladores, yuri, tarefas, 1).
materia(ia, yuri, notas, 93).
materia(ia, yuri, faltas, 1).
materia(ia, yuri, tarefas, 999).
materia(jogos, yuri, notas, 97).
materia(jogos, yuri, faltas, 2).
materia(jogos, yuri, tarefas, 3).
materia(aeds, yuri, notas, 88).
materia(aeds, yuri, faltas, 4).
materia(aeds, yuri, tarefas, 3).
materia(lfa, yuri, notas, 83).
materia(lfa, yuri, faltas, 3).
materia(lfa, yuri, tarefas, 3).
materia(compiladores, rodrigo, notas, 77).
materia(compiladores, rodrigo, faltas, 3).
materia(compiladores, rodrigo, tarefas, 2).
materia(ia, rodrigo, notas, 90).
materia(ia, rodrigo, faltas, 3).
materia(ia, rodrigo, tarefas, 1000).
materia(jogos, rodrigo, notas, 92).
materia(jogos, rodrigo, faltas, 1).
materia(jogos, rodrigo, tarefas, 2).
materia(aeds, rodrigo, notas, 82).
materia(aeds, rodrigo, faltas, 2).
materia(aeds, rodrigo, tarefas, 2).
materia(lfa, rodrigo, notas, 87).
materia(lfa, rodrigo, faltas, 2).
materia(lfa, rodrigo, tarefas, 1).

pendente(rodrigo,[fisica1, aeds, lfa, tcc]).
pendente(gabriel,[ia,compiladores,tcc]).
pendente(yuri,[ia,jogos,tcc]).